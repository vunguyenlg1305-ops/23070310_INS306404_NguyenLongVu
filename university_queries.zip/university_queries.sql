-- =====================================================================
-- Student Name : Nguyễn Long Vũ
-- Student ID   : SV2026001
-- Assignment   : INS3064 - Homework 5 (SQL Queries Assignment)
-- Date         : 2026-10-12
-- Description  : SQL script containing 10 required queries for university_db
-- =====================================================================

USE university_db;

-- =====================================================================
-- Query 1: Basic SELECT
-- =====================================================================
/*
Query 1: List All Students
Description: Retrieve all columns and records from the students table to view complete student profiles.
Expected Output: A table displaying all student fields including id, student_code, full_name, email, gender, date_of_birth, gpa, and department_id.
 */
SELECT * 
FROM students;

/*
+----+--------------+-------------------+------------------------+--------+---------------+------+---------------+
| id | student_code | full_name         | email                  | gender | date_of_birth | gpa  | department_id |
+----+--------------+-------------------+------------------------+--------+---------------+------+---------------+
|  1 | SV2026001    | Nguyễn Long Vũ    | vu.nl@student.edu.vn   | Nam    | 2005-03-15    | 3.65 |             1 |
|  2 | SV2026002    | Trần Bảo Ngọc     | ngoc.tb@student.edu.vn | Nữ     | 2005-07-22    | 3.80 |             1 |
|  3 | SV2026003    | Lê Minh Tuấn      | tuan.lm@student.edu.vn | Nam    | 2005-11-04    | 3.20 |             2 |
|  4 | SV2026004    | Phạm Thu Hằng     | hang.pt@student.edu.vn | Nữ     | 2005-01-19    | 3.50 |             3 |
|  5 | SV2026005    | Võ Hoàng Gia Huy  | huy.vhg@student.edu.vn | Nam    | 2005-09-30    | 3.10 |             4 |
+----+--------------+-------------------+------------------------+--------+---------------+------+---------------+
(5 rows)
 */


-- =====================================================================
-- Query 2: WHERE with comparison
-- =====================================================================
/*
Query 2: Students with High GPA
Description: Filter and retrieve students whose GPA is strictly greater than 3.50 to identify top-performing students.
Expected Output: A list of students who have a GPA higher than 3.50.
 */
SELECT * 
FROM students 
WHERE gpa > 3.50;

/*
+----+--------------+----------------+------------------------+--------+---------------+------+---------------+
| id | student_code | full_name      | email                  | gender | date_of_birth | gpa  | department_id |
+----+--------------+----------------+------------------------+--------+---------------+------+---------------+
|  1 | SV2026001    | Nguyễn Long Vũ | vu.nl@student.edu.vn   | Nam    | 2005-03-15    | 3.65 |             1 |
|  2 | SV2026002    | Trần Bảo Ngọc  | ngoc.tb@student.edu.vn | Nữ     | 2005-07-22    | 3.80 |             1 |
+----+--------------+----------------+------------------------+--------+---------------+------+---------------+
(2 rows)
 */


-- =====================================================================
-- Query 3: WHERE with AND/OR
-- =====================================================================
/*
Query 3: IT Department Courses with 3 or More Credits
Description: Find courses belonging to department ID 1 (Information Technology) that require 3 or more credits.
Expected Output: List of IT courses with credits >= 3.
 */
SELECT * 
FROM courses 
WHERE department_id = 1 AND credits >= 3;

/*
+----+-------------+----------------------------------+---------+--------------------------------------------------------------+---------------+---------------+
| id | course_code | title                            | credits | description                                                  | department_id | instructor_id |
+----+-------------+----------------------------------+---------+--------------------------------------------------------------+---------------+---------------+
|  1 | INS3064     | Cơ sở dữ liệu quan hệ và MySQL   |       3 | Học phần về thiết kế CSDL quan hệ, cú pháp SQL nâng cao...   |             1 |             1 |
|  2 | IT1010      | Nhập môn Lập trình C             |       3 | Khái niệm cơ bản về lập trình cấu trúc, biến, mảng...        |             1 |             2 |
+----+-------------+----------------------------------+---------+--------------------------------------------------------------+---------------+---------------+
(2 rows)
 */


-- =====================================================================
-- Query 4: ORDER BY
-- =====================================================================
/*
Query 4: Students Sorted by Full Name
Description: Retrieve student codes, full names, and GPAs ordered alphabetically by their full name in ascending order.
Expected Output: Sorted table of students from A to Z by name.
 */
SELECT student_code, full_name, gpa 
FROM students 
ORDER BY full_name ASC;

/*
+--------------+-------------------+------+
| student_code | full_name         | gpa  |
+--------------+-------------------+------+
|  SV2026003   | Lê Minh Tuấn      | 3.20 |
|  SV2026004   | Phạm Thu Hằng     | 3.50 |
|  SV2026002   | Trần Bảo Ngọc     | 3.80 |
|  SV2026001   | Nguyễn Long Vũ    | 3.65 |
|  SV2026005   | Võ Hoàng Gia Huy  | 3.10 |
+--------------+-------------------+------+
(5 rows)
 */


-- =====================================================================
-- Query 5: LIMIT
-- =====================================================================
/*
Query 5: Top 3 Highest Grades in Enrollments
Description: Retrieve the top 3 enrollment records with the highest grades achieved across all courses.
Expected Output: 3 enrollment rows sorted by grade in descending order.
 */
SELECT * 
FROM enrollments 
ORDER BY grade DESC 
LIMIT 3;

/*
+----+------------+-----------+-------------+-------+---------------------+
| id | student_id | course_id | semester_id | grade | enrolled_at         |
+----+------------+-----------+-------------+-------+---------------------+
|  3 |          2 |         1 |           4 |  4.00 | 2026-10-12 00:00:00 |
|  1 |          1 |         1 |           4 |  3.80 | 2026-10-12 00:00:00 |
|  4 |          2 |         2 |           3 |  3.70 | 2026-10-12 00:00:00 |
+----+------------+-----------+-------------+-------+---------------------+
(3 rows)
 */


-- =====================================================================
-- Query 6: LIKE
-- =====================================================================
/*
Query 6: Instructors Starting with 'Ng'
Description: Search for instructors whose full names start with the Vietnamese family name "Ng" (e.g., Nguyễn).
Expected Output: List of instructors matching the name pattern.
 */
SELECT * 
FROM instructors 
WHERE full_name LIKE 'Ng%';

/*
+----+-----------------+-----------------+---------------------------+--------+---------------+
| id | instructor_code | full_name       | email                     | gender | department_id |
+----+-----------------+-----------------+---------------------------+--------+---------------+
|  1 | INS101          | Nguyễn Văn Minh | minh.nv@university.edu.vn | Nam    |             1 |
+----+-----------------+-----------------+---------------------------+--------+---------------+
(1 row)
 */


-- =====================================================================
-- Query 7: Aggregate — COUNT / SUM
-- =====================================================================
/*
Query 7: Student Count Per Department
Description: Count the total number of students enrolled in each department using GROUP BY and an aggregate function, utilizing column aliases (AS).
Expected Output: Summary table showing department ID and total number of students.
 */
SELECT department_id, COUNT(*) AS total_students 
FROM students 
GROUP BY department_id;

/*
+---------------+----------------+
| department_id | total_students |
+---------------+----------------+
|             1 |          2     |
|             2 |          1     |
|             3 |          1     |
|             4 |          1     |
+---------------+----------------+
(4 rows)
 */


-- =====================================================================
-- Query 8: Aggregate with GROUP BY + HAVING
-- =====================================================================
/*
Query 8: Students Enrolled in More Than 1 Course
Description: Find students who have registered for more than 1 course by grouping enrollment records and filtering using HAVING.
Expected Output: List of student IDs and their respective course counts greater than 1.
 */
SELECT student_id, COUNT(course_id) AS courses_enrolled 
FROM enrollments 
GROUP BY student_id 
HAVING COUNT(course_id) > 1;

/*
+------------+------------------+
| student_id | courses_enrolled |
+------------+------------------+
|          1 |                2 |
|          2 |                2 |
|          3 |                2 |
|          4 |                2 |
|          5 |                2 |
+------------+------------------+
(5 rows)
 */


-- =====================================================================
-- Query 9: JOIN — two tables
-- =====================================================================
/*
Query 9: Courses with Instructor Names
Description: Join the courses table with the instructors table using their foreign key relationship to display course titles alongside their respective instructor names, using column aliases (AS).
Expected Output: Table containing course codes, titles, and instructor full names.
 */
SELECT c.course_code, c.title, i.full_name AS instructor_name 
FROM courses c 
JOIN instructors i ON c.instructor_id = i.id;

/*
+-------------+----------------------------------+-----------------+
| course_code | title                            | instructor_name |
+-------------+----------------------------------+-----------------+
| INS3064     | Cơ sở dữ liệu quan hệ và MySQL   | Nguyễn Văn Minh |
| IT1010      | Nhập môn Lập trình C             | Trần Thị Mai    |
| BA1001      | Quản trị học đại cương           | Lê Hoàng Long   |
| EE2001      | Mạch điện tử cơ bản              | Phạm Thị Lan    |
| ENG101      | Tiếng Anh chuyên ngành kỹ thuật  | Hoàng Văn Hùng  |
+-------------+----------------------------------+-----------------+
(5 rows)
 */


-- =====================================================================
-- Query 10: JOIN — three or more tables
-- =====================================================================
/*
Query 10: Detailed Enrollment Report
Description: Perform a multi-table join across enrollments, students, courses, and semesters to display comprehensive registration information including student name, course title, semester name, and grade, utilizing column aliases (AS).
Expected Output: Detailed report list showing student name, course name, semester, and grade.
 */
SELECT 
    s.full_name AS student_name, 
    c.title AS course_title, 
    sem.name AS semester_name, 
    e.grade 
FROM enrollments e 
JOIN students s ON e.student_id = s.id 
JOIN courses c ON e.course_id = c.id 
JOIN semesters sem ON e.semester_id = sem.id;

/*
+------------------+----------------------------------+---------------+-------+
| student_name     | course_title                     | semester_name | grade |
+------------------+----------------------------------+---------------+-------+
| Nguyễn Long Vũ   | Cơ sở dữ liệu quan hệ và MySQL   | Spring 2026   |  3.80 |
| Nguyễn Long Vũ   | Nhập môn Lập trình C             | Fall 2025     |  3.50 |
| Trần Bảo Ngọc    | Cơ sở dữ liệu quan hệ và MySQL   | Spring 2026   |  4.00 |
| Trần Bảo Ngọc    | Nhập môn Lập trình C             | Fall 2025     |  3.70 |
| Lê Minh Tuấn     | Quản trị học đại cương           | Fall 2025     |  3.20 |
| Lê Minh Tuấn     | Cơ sở dữ liệu quan hệ và MySQL   | Spring 2026   |  3.00 |
| Phạm Thu Hằng    | Mạch điện tử cơ bản              | Fall 2025     |  3.40 |
| Phạm Thu Hằng    | Cơ sở dữ liệu quan hệ và MySQL   | Spring 2026   |  3.60 |
| Võ Hoàng Gia Huy | Tiếng Anh chuyên ngành kỹ thuật  | Fall 2025     |  3.10 |
| Võ Hoàng Gia Huy | Cơ sở dữ liệu quan hệ và MySQL   | Spring 2026   |  3.30 |
+------------------+----------------------------------+---------------+-------+
(10 rows)
 */