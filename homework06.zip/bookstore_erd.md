# Homework 06: Online Bookstore Database Design
## Entity-Relationship Diagram (ERD) & 3NF Normalization

- **Course:** INS3064 - Multimedia Design and Web Development
- **Institution:** International School, Vietnam National University, Hanoi (IS-VNU)
- **Student Name:** Nguyễn Long Vũ
- **Student ID:** SV2026001
- **Deliverables:** `bookstore_erd.md`, `bookstore_db.sql`

---

## 1. System Overview

The **Online Bookstore Database** is a comprehensive relational database system designed to support an e-commerce platform for books. The database handles:
1. **Catalog Management:** Books with ISBN-10/13 identifiers, titles, pricing, inventory stock levels, publication dates, language, and page counts.
2. **Authors & Publishers:** Authors with biographies, nationalities, and birth dates; Publishers with contact details and official websites. Supports co-authorship via a many-to-many (M:N) junction table, and a 1:N publisher-to-books relationship.
3. **Hierarchical Categorization:** Categories with self-referencing parent/child relationships (e.g., Literature $\rightarrow$ Novels) and M:N book-to-category associations.
4. **Customer Accounts:** Secure user authentication with password hashing, unique email addresses, phone numbers, and delivery addresses.
5. **Orders & Transactions:** Complete order tracking (order date, status, payment method, shipping destination) and line items (`order_items`) that preserve historical purchase prices (point-in-time snapshot).
6. **Reviews & Ratings:** Customer ratings (1 to 5 stars) and feedback comments for books.

The database is normalized to **Third Normal Form (3NF)** to eliminate redundancy and insertion/update/deletion anomalies.

---

## 2. Visual ERD Diagram (Mermaid)

```mermaid
erDiagram
    PUBLISHERS ||--o{ BOOKS : "publishes (1:N)"
    CATEGORIES ||--o{ CATEGORIES : "parent of (1:N)"
    CATEGORIES ||--o{ BOOK_CATEGORIES : "categorizes (1:N)"
    BOOKS ||--o{ BOOK_CATEGORIES : "belongs to (1:N)"
    AUTHORS ||--o{ BOOK_AUTHORS : "writes (1:N)"
    BOOKS ||--o{ BOOK_AUTHORS : "written by (1:N)"
    CUSTOMERS ||--o{ ORDERS : "places (1:N)"
    ORDERS ||--|{ ORDER_ITEMS : "contains (1:N)"
    BOOKS ||--o{ ORDER_ITEMS : "sold in (1:N)"
    CUSTOMERS ||--o{ REVIEWS : "submits (1:N)"
    BOOKS ||--o{ REVIEWS : "receives (1:N)"

    PUBLISHERS {
        int id PK "Publisher ID"
        varchar name UK "Publisher Name"
        varchar address "Headquarters Address"
        varchar phone "Phone Number"
        varchar email UK "Contact Email"
        varchar website "Official Website"
        datetime created_at "Created Timestamp"
    }

    AUTHORS {
        int id PK "Author ID"
        varchar name "Author Full Name"
        text bio "Biography"
        varchar nationality "Nationality"
        date birth_date "Date of Birth"
        datetime created_at "Created Timestamp"
    }

    CATEGORIES {
        int id PK "Category ID"
        varchar name UK "Category Name"
        text description "Description"
        int parent_id FK "Parent Category ID (Self-ref)"
        datetime created_at "Created Timestamp"
    }

    BOOKS {
        int id PK "Book ID"
        varchar title "Book Title"
        varchar isbn UK "Standard ISBN-10/13"
        decimal price "List Price (> 0)"
        int stock_quantity "Stock Quantity (>= 0)"
        date publication_date "Publication Date"
        int pages "Number of Pages (> 0)"
        varchar language "Edition Language"
        text description "Book Synopsis"
        int publisher_id FK "Publisher Reference"
        datetime created_at "Created Timestamp"
        datetime updated_at "Updated Timestamp"
    }

    BOOK_AUTHORS {
        int book_id PK, FK "Book ID"
        int author_id PK, FK "Author ID"
        varchar role "Role (Lead Author, Co-Author, Translator)"
    }

    BOOK_CATEGORIES {
        int book_id PK, FK "Book ID"
        int category_id PK, FK "Category ID"
    }

    CUSTOMERS {
        int id PK "Customer ID"
        varchar full_name "Customer Full Name"
        varchar email UK "Login Email"
        varchar password_hash "Hashed Password"
        varchar phone "Contact Phone"
        varchar address "Default Shipping Address"
        datetime created_at "Registration Date"
    }

    ORDERS {
        int id PK "Order ID"
        int customer_id FK "Customer Reference"
        datetime order_date "Order Placement Date"
        enum status "Pending/Processing/Shipped/Delivered/Cancelled"
        decimal total_amount "Total Amount (>= 0)"
        varchar shipping_address "Delivery Destination"
        enum payment_method "COD/Credit Card/Bank Transfer/E-Wallet"
        datetime created_at "Created Timestamp"
    }

    ORDER_ITEMS {
        int id PK "Order Item ID"
        int order_id FK "Order Reference"
        int book_id FK "Book Reference"
        int quantity "Purchased Quantity (> 0)"
        decimal unit_price "Historical Unit Price (> 0)"
        decimal subtotal "Subtotal = qty * price (>= 0)"
    }

    REVIEWS {
        int id PK "Review ID"
        int book_id FK "Book Reference"
        int customer_id FK "Customer Reference"
        tinyint rating "Score (1 to 5)"
        text comment "Customer Comment"
        datetime review_date "Submission Timestamp"
    }
```

---

## 3. Text-Based Crow's Foot ERD Diagram

```text
===================================================================================================
                    TEXT-BASED ENTITY-RELATIONSHIP DIAGRAM (CROW'S FOOT NOTATION)
===================================================================================================

      +-------------------------+
      |       PUBLISHERS        |
      +-------------------------+
      | PK  id                  |
      |     name (UNIQUE)       |
      |     address             |
      |     phone               |
      |     email (UNIQUE)      |
      |     website             |
      |     created_at          |
      +------------+------------+
                   | 1
                   |
                   | n (One publisher publishes many books)
                   v
      +-------------------------+                           +-------------------------+
      |          BOOKS          | 1                       n |      BOOK_AUTHORS       |
      +-------------------------+---------------------------+-------------------------+
      | PK  id                  |                           | PK,FK1  book_id         |
      |     title               |                           | PK,FK2  author_id       |
      |     isbn (UNIQUE)       |                           |         role            |
      |     price               |                           +------------+------------+
      |     stock_quantity      |                                        | n
      |     publication_date    |                                        |
      |     pages               |                                        | 1 (Author writes many)
      |     language            |                                        v
      |     description         |                           +-------------------------+
      | FK  publisher_id        |                           |         AUTHORS         |
      |     created_at          |                           +-------------------------+
      |     updated_at          |                           | PK  id                  |
      +------------+------------+                           |     name                |
          | 1             | 1                               |     bio                 |
          |               |                                 |     nationality         |
          | n             | n (Book in many categories)     |     birth_date          |
          |               v                                 |     created_at          |
          |   +-------------------------+                   +-------------------------+
          |   |     BOOK_CATEGORIES     |
          |   +-------------------------+
          |   | PK,FK1  book_id         |
          |   | PK,FK2  category_id     |
          |   +------------+------------+
          |                | n
          |                |
          |                | 1
          |                v
          |   +-------------------------+
          |   |       CATEGORIES        |<-------+
          |   +-------------------------+        | 1 (Parent Category)
          |   | PK  id                  |        |
          |   |     name (UNIQUE)       |        |
          |   |     description         |        | n (Has sub-categories)
          |   | FK  parent_id ----------+--------+
          |   |     created_at          |
          |   +-------------------------+
          |
          | 1 (Books can have multiple reviews and be purchased)
          +-------------------------------------------+
          |                                           |
          | n                                         | n
          v                                           v
+-------------------------+               +-------------------------+
|         REVIEWS         |               |       ORDER_ITEMS       |
+-------------------------+               +-------------------------+
| PK  id                  |               | PK  id                  |
| FK1 book_id             |               | FK1 order_id            |
| FK2 customer_id         |               | FK2 book_id             |
|     rating (1..5)       |               |     quantity (> 0)      |
|     comment             |               |     unit_price (> 0)    |
|     review_date         |               |     subtotal (>= 0)     |
+------------+------------+               +------------+------------+
             | n                                       | n
             |                                         |
             | (1 customer writes many reviews)        | (1 order contains many items)
             | 1                                       | 1
+------------+------------+               +------------+------------+
|        CUSTOMERS        | 1           n |         ORDERS          |
+-------------------------+---------------+-------------------------+
| PK  id                  |               | PK  id                  |
|     full_name           |               | FK  customer_id         |
|     email (UNIQUE)      |               |     order_date          |
|     password_hash       |               |     status (ENUM)       |
|     phone               |               |     total_amount        |
|     address             |               |     shipping_address    |
|     created_at          |               |     payment_method      |
+-------------------------+               |     created_at          |
                                          +-------------------------+
```

---

## 4. Entity Specifications & Data Dictionary

### 4.1. Table: `publishers`
Stores publishing houses responsible for printing and releasing books.

| Column | Data Type | Key / Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | `INT` | `PK`, `AUTO_INCREMENT` | Unique identifier for each publisher. |
| `name` | `VARCHAR(150)` | `NOT NULL`, `UNIQUE` | Company / publishing house name. |
| `address` | `VARCHAR(255)` | `NULL` | Headquarters / physical address. |
| `phone` | `VARCHAR(20)` | `NULL` | Business contact phone number. |
| `email` | `VARCHAR(100)` | `UNIQUE`, `NULL` | Business email address. |
| `website` | `VARCHAR(150)` | `NULL` | Official website URL. |
| `created_at`| `DATETIME` | `DEFAULT CURRENT_TIMESTAMP` | Record creation timestamp. |

---

### 4.2. Table: `authors`
Stores information about book writers and contributors.

| Column | Data Type | Key / Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | `INT` | `PK`, `AUTO_INCREMENT` | Unique identifier for each author. |
| `name` | `VARCHAR(100)` | `NOT NULL` | Author full name. |
| `bio` | `TEXT` | `NULL` | Biography and career overview. |
| `nationality` | `VARCHAR(50)` | `NULL` | Nationality / country of origin. |
| `birth_date` | `DATE` | `NULL` | Date of birth. |
| `created_at` | `DATETIME` | `DEFAULT CURRENT_TIMESTAMP` | Record creation timestamp. |

---

### 4.3. Table: `categories`
Stores hierarchical genres and sub-genres via self-referencing foreign key.

| Column | Data Type | Key / Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | `INT` | `PK`, `AUTO_INCREMENT` | Unique category identifier. |
| `name` | `VARCHAR(100)` | `NOT NULL`, `UNIQUE` | Unique genre name. |
| `description`| `TEXT` | `NULL` | Description of the genre. |
| `parent_id` | `INT` | `FK (categories.id)`, `NULL` | Parent category reference (NULL for root genres). |
| `created_at` | `DATETIME` | `DEFAULT CURRENT_TIMESTAMP` | Record creation timestamp. |

---

### 4.4. Table: `books`
Core entity representing the bookstore product catalog.

| Column | Data Type | Key / Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | `INT` | `PK`, `AUTO_INCREMENT` | Unique surrogate book identifier. |
| `title` | `VARCHAR(255)` | `NOT NULL` | Book title. |
| `isbn` | `VARCHAR(20)` | `NOT NULL`, `UNIQUE` | Standard Book Number (ISBN-10 or 13). |
| `price` | `DECIMAL(10, 2)`| `NOT NULL`, `CHECK (price > 0)` | Catalog list price. |
| `stock_quantity` | `INT` | `NOT NULL`, `DEFAULT 0`, `CHECK (stock_quantity >= 0)` | Available warehouse inventory. |
| `publication_date` | `DATE` | `NULL` | Date of publication. |
| `pages` | `INT` | `CHECK (pages > 0)`, `NULL` | Total page count. |
| `language` | `VARCHAR(50)` | `DEFAULT 'Tiếng Việt'` | Publication language. |
| `description`| `TEXT` | `NULL` | Book synopsis and overview. |
| `publisher_id` | `INT` | `NOT NULL`, `FK (publishers.id)` | Publishing house foreign key. |
| `created_at` | `DATETIME` | `DEFAULT CURRENT_TIMESTAMP` | Record creation timestamp. |
| `updated_at` | `DATETIME` | `DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP` | Last updated timestamp. |

---

### 4.5. Table: `book_authors`
Junction table resolving the Many-to-Many (M:N) relationship between `books` and `authors`.

| Column | Data Type | Key / Constraints | Description |
| :--- | :--- | :--- | :--- |
| `book_id` | `INT` | `PK`, `FK (books.id)` | Book reference (`ON DELETE CASCADE`). |
| `author_id` | `INT` | `PK`, `FK (authors.id)`| Author reference (`ON DELETE CASCADE`). |
| `role` | `VARCHAR(50)` | `DEFAULT 'Tác giả chính'` | Author role (Lead Author, Co-Author, Translator). |

---

### 4.6. Table: `book_categories`
Junction table resolving the Many-to-Many (M:N) relationship between `books` and `categories`.

| Column | Data Type | Key / Constraints | Description |
| :--- | :--- | :--- | :--- |
| `book_id` | `INT` | `PK`, `FK (books.id)` | Book reference (`ON DELETE CASCADE`). |
| `category_id` | `INT` | `PK`, `FK (categories.id)` | Category reference (`ON DELETE CASCADE`). |

---

### 4.7. Table: `customers`
Customer profiles, authentication credentials, and contact details.

| Column | Data Type | Key / Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | `INT` | `PK`, `AUTO_INCREMENT` | Unique customer identifier. |
| `full_name` | `VARCHAR(100)` | `NOT NULL` | Full customer name. |
| `email` | `VARCHAR(100)` | `NOT NULL`, `UNIQUE` | Unique email for authentication. |
| `password_hash`| `VARCHAR(255)` | `NOT NULL` | Secure salted password hash (bcrypt). |
| `phone` | `VARCHAR(20)` | `NULL` | Contact phone number. |
| `address` | `VARCHAR(255)` | `NOT NULL` | Default billing and shipping address. |
| `created_at` | `DATETIME` | `DEFAULT CURRENT_TIMESTAMP` | Registration timestamp. |

---

### 4.8. Table: `orders`
Order header capturing transaction lifecycle, summary financial values, and destination.

| Column | Data Type | Key / Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | `INT` | `PK`, `AUTO_INCREMENT` | Unique order identifier. |
| `customer_id` | `INT` | `NOT NULL`, `FK (customers.id)` | Purchasing customer reference (`ON DELETE RESTRICT`). |
| `order_date` | `DATETIME` | `NOT NULL`, `DEFAULT CURRENT_TIMESTAMP` | Timestamp when order was placed. |
| `status` | `ENUM(...)` | `NOT NULL`, `DEFAULT 'Pending'` | `'Pending'`, `'Processing'`, `'Shipped'`, `'Delivered'`, `'Cancelled'`. |
| `total_amount`| `DECIMAL(12, 2)`| `NOT NULL`, `DEFAULT 0.00`, `CHECK (total_amount >= 0)` | Total payable amount. |
| `shipping_address`| `VARCHAR(255)`| `NOT NULL` | Actual delivery address for this order. |
| `payment_method` | `ENUM(...)` | `NOT NULL`, `DEFAULT 'COD'` | `'COD'`, `'Credit Card'`, `'Bank Transfer'`, `'E-Wallet'`. |
| `created_at` | `DATETIME` | `DEFAULT CURRENT_TIMESTAMP` | Order record creation timestamp. |

---

### 4.9. Table: `order_items`
Order line items resolving the Many-to-Many (M:N) relationship between `orders` and `books`.

| Column | Data Type | Key / Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | `INT` | `PK`, `AUTO_INCREMENT` | Surrogate line item identifier. |
| `order_id` | `INT` | `NOT NULL`, `FK (orders.id)` | Order reference (`ON DELETE CASCADE`). |
| `book_id` | `INT` | `NOT NULL`, `FK (books.id)` | Book reference (`ON DELETE RESTRICT`). |
| `quantity` | `INT` | `NOT NULL`, `CHECK (quantity > 0)` | Quantity purchased. |
| `unit_price` | `DECIMAL(10, 2)`| `NOT NULL`, `CHECK (unit_price > 0)` | Point-in-time snapshot price at time of purchase. |
| `subtotal` | `DECIMAL(12, 2)`| `NOT NULL`, `CHECK (subtotal >= 0)` | Line subtotal (`quantity * unit_price`). |

> **Composite Unique Constraint:** `UNIQUE KEY uq_order_book (order_id, book_id)` guarantees that a book cannot appear multiple times in the same order.

---

### 4.10. Table: `reviews`
Customer ratings and reviews for books.

| Column | Data Type | Key / Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | `INT` | `PK`, `AUTO_INCREMENT` | Unique review identifier. |
| `book_id` | `INT` | `NOT NULL`, `FK (books.id)` | Reviewed book reference (`ON DELETE CASCADE`). |
| `customer_id` | `INT` | `NOT NULL`, `FK (customers.id)` | Reviewer reference (`ON DELETE CASCADE`). |
| `rating` | `TINYINT` | `NOT NULL`, `CHECK (rating BETWEEN 1 AND 5)` | Rating score from 1 to 5 stars. |
| `comment` | `TEXT` | `NULL` | Written review text. |
| `review_date` | `DATETIME` | `NOT NULL`, `DEFAULT CURRENT_TIMESTAMP` | Review submission timestamp. |

> **Composite Unique Constraint:** `UNIQUE KEY uq_customer_book_review (customer_id, book_id)` ensures each customer may submit only one official review per book.

---

## 5. Relationship Cardinality & Referential Integrity Matrix

| Source Entity | Cardinality | Target Entity | Junction Table | Business Logic | ON DELETE Action | ON UPDATE Action |
| :--- | :---: | :--- | :--- | :--- | :--- | :--- |
| `publishers` | **1 : N** | `books` | None | A publisher prints many books; each book belongs to exactly one publisher. | `RESTRICT` (Cannot delete publisher if books exist) | `CASCADE` |
| `authors` | **M : N** | `books` | `book_authors` | An author writes many books; a book can have multiple co-authors. | `CASCADE` | `CASCADE` |
| `categories` | **M : N** | `books` | `book_categories` | A category contains many books; a book can be classified under multiple genres. | `CASCADE` | `CASCADE` |
| `categories` | **1 : N** | `categories` | None | Self-referencing: One parent category has multiple sub-genres. | `SET NULL` (Children become top-level if parent deleted) | `CASCADE` |
| `customers` | **1 : N** | `orders` | None | A customer can place multiple orders over time. | `RESTRICT` (Preserves order history) | `CASCADE` |
| `orders` | **M : N** | `books` | `order_items` | An order contains multiple books; a book appears in multiple customer orders. | Order: `CASCADE`<br>Book: `RESTRICT` | `CASCADE` |
| `customers` | **1 : N** | `reviews` | None | A customer can write multiple reviews for different books. | `CASCADE` | `CASCADE` |
| `books` | **1 : N** | `reviews` | None | A book receives multiple ratings and reviews from readers. | `CASCADE` | `CASCADE` |

---

## 6. Comprehensive 3NF Normalization Analysis

The database was engineered following relational normalization theory, progressing sequentially through 1NF, 2NF, and 3NF.

### 6.1. First Normal Form (1NF)
- **Requirements:**
  1. Each column must hold strictly **atomic values** (single, indivisible scalar data).
  2. No **repeating groups** or multi-valued arrays across columns (e.g., no `author_1`, `author_2`, or CSV strings like `"Sci-Fi, Fantasy"`).
  3. A defined **Primary Key** must uniquely identify each record.
- **Proof of Compliance:**
  - Authors are stored individually in `authors`, linked through the `book_authors` junction table rather than comma-separated lists in `books`.
  - Categories are stored in `categories` and linked via `book_categories`.
  - Ordered items are broken down into individual atomic rows in `order_items` instead of packing multiple items into `orders`.
  - Every table has an explicit Primary Key.

### 6.2. Second Normal Form (2NF)
- **Requirements:**
  1. The schema must satisfy 1NF.
  2. Every non-key attribute must be **fully functionally dependent** on the entire primary key, with **zero partial dependencies** on any subset of a composite primary key.
- **Proof of Compliance:**
  - For tables with single-column surrogate primary keys (`publishers`, `authors`, `categories`, `books`, `customers`, `orders`, `order_items`, `reviews`), partial dependency is mathematically impossible because the key cannot be divided.
  - In `book_authors` with composite key `(book_id, author_id)`: The only non-key attribute is `role`, which describes the relationship between *this specific author* and *this specific book*. Author names and bios are placed in `authors` (dependent strictly on `author_id`), avoiding partial dependency.
  - In `book_categories` with composite key `(book_id, category_id)`: Contains only foreign keys with no extra non-key attributes.
  - In `order_items`: Attributes `quantity`, `unit_price`, and `subtotal` depend fully on the specific line item within that order. Book title, ISBN, and stock remain in `books`.

### 6.3. Third Normal Form (3NF)
- **Requirements:**
  1. The schema must satisfy 2NF.
  2. There must be **no transitive functional dependencies** between non-key attributes ($X \rightarrow Y$ and $Y \rightarrow Z$ where $Z$ is non-key). Every non-key attribute must depend *directly and only* on the primary key.
- **Proof of Compliance:**
  - **`books` Table:** Sách chỉ lưu `publisher_id`. If `publisher_name`, `address`, and `phone` were kept in `books`, we would have:
    $$\text{book\_id} \rightarrow \text{publisher\_id} \rightarrow \{\text{name, address, phone}\}$$
    This transitive dependency was eliminated by isolating publisher details into the separate `publishers` table.
  - **`orders` Table:** Đơn hàng chỉ lưu `customer_id`. Customer details (`full_name`, `email`, `phone`) reside in `customers`, eliminating transitive dependency on `orders.id`.
  - **`order_items.unit_price` Justification:**
    - The price in `books.price` is the dynamic, current catalog price.
    - The `unit_price` in `order_items` represents the **point-in-time transaction price** agreed upon when the contract was made. It is an immutable attribute of that specific transaction row, NOT a transitive dependency on `books.price`.
  - **`orders.shipping_address` Justification:**
    - `customers.address` is the account holder's default residence.
    - `orders.shipping_address` is the specific destination requested for that shipment (e.g., office, gift recipient). It directly depends on `order_id`.

---