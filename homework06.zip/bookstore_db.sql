-- =====================================================================
-- Student Name : Nguyễn Long Vũ
-- Student ID   : SV2026001
-- Assignment   : INS3064 - Homework 6 (Online Bookstore Database Design)
-- Institution  : International School, Vietnam National University, Hanoi
-- Date         : 2026-10-19
-- Description  : Complete SQL script for bookstore_db database:
--                - 3NF Normalization Explanation Block
--                - DDL for 10 tables with primary/foreign keys & constraints
--                - Realistic sample dataset (5 publishers, 8 authors, 
--                  7 categories, 10 books, 6 customers, 6 orders with 
--                  15 items, and 12 reviews)
--                - Integrity verification queries
-- =====================================================================

/*
===================================================================================================
                       3NF NORMALIZATION ANALYSIS / GIẢI THÍCH CHUẨN HÓA 3NF
===================================================================================================

1. FIRST NORMAL FORM (1NF) / DẠNG CHUẨN 1:
   - Atomic Values: All column values are strictly atomic and non-divisible scalars (e.g., standard 
     VARCHAR, INT, DECIMAL, DATE). No multi-valued sets, arrays, or comma-separated strings are used.
   - No Repeating Groups: Rather than using repetitive columns such as `author_1, author_2` or 
     `category_1, category_2` within `books`, relationships are handled through dedicated junction 
     tables (`book_authors` and `book_categories`).
   - Defined Primary Keys: Every table has an unambiguous Primary Key (auto-increment surrogate key 
     or composite primary key for junction tables).

2. SECOND NORMAL FORM (2NF) / DẠNG CHUẨN 2:
   - Meets 1NF requirements.
   - Full Functional Dependency: Every non-key attribute depends entirely on the whole primary key; 
     there are zero partial dependencies on a proper subset of any candidate/composite key.
   - For single-column primary keys (`publishers`, `authors`, `categories`, `books`, `customers`, 
     `orders`, `order_items`, `reviews`), 2NF is automatically satisfied because the PK cannot be split.
   - In junction table `book_authors` (PK: `book_id, author_id`), the attribute `role` describes the 
     specific participation of that author for that specific book, thus depending on the entire composite PK. 
     General author details (`name`, `bio`) remain in `authors` (dependent strictly on `author_id`).
   - In junction table `book_categories` (PK: `book_id, category_id`), only the composite key exists.

3. THIRD NORMAL FORM (3NF) / DẠNG CHUẨN 3:
   - Meets 2NF requirements.
   - No Transitive Dependencies: Non-key attributes depend only directly on the primary key, never 
     transitively through another non-key attribute.
   - `books` table: Contains `publisher_id` as a foreign key. Publisher details (`name`, `address`, 
     `phone`, `website`) are maintained in `publishers`. Storing them in `books` would create the 
     transitive dependency: `book_id -> publisher_id -> {publisher_name, publisher_address}`, causing 
     update anomalies.
   - `orders` table: Contains `customer_id` as a foreign key. Personal details (`full_name`, `email`, 
     `phone`) reside exclusively in `customers`.
   - `order_items.unit_price`: Captures the historical transaction price at checkout time (point-in-time 
     snapshot). Since catalog book prices change over time, this unit price belongs strictly to the 
     transaction item itself and is not a transitive duplicate of `books.price`.
   - `categories.parent_id`: Self-referencing foreign key allows multi-level hierarchical genres 
     without creating transitive anomalies or redundant tables.
===================================================================================================
*/

-- ---------------------------------------------------------------------
-- DATABASE INITIALIZATION (IDEMPOTENT SCRIPT)
-- ---------------------------------------------------------------------
DROP DATABASE IF EXISTS bookstore_db;
CREATE DATABASE bookstore_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE bookstore_db;

-- =====================================================================
-- 1. TABLE: publishers
-- Stores publishing companies and distribution houses
-- =====================================================================
CREATE TABLE publishers (
    id          INT AUTO_INCREMENT PRIMARY KEY COMMENT 'Publisher ID (PK)',
    name        VARCHAR(150) NOT NULL UNIQUE COMMENT 'Publisher Name (Unique)',
    address     VARCHAR(255) NULL COMMENT 'Headquarters address',
    phone       VARCHAR(20)  NULL COMMENT 'Contact telephone number',
    email       VARCHAR(100) NULL UNIQUE COMMENT 'Official business email',
    website     VARCHAR(150) NULL COMMENT 'Official website URL',
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT 'Record creation timestamp'
) ENGINE=InnoDB COMMENT='Publishers information';

-- =====================================================================
-- 2. TABLE: authors
-- Stores biographical details of authors and writers
-- =====================================================================
CREATE TABLE authors (
    id          INT AUTO_INCREMENT PRIMARY KEY COMMENT 'Author ID (PK)',
    name        VARCHAR(100) NOT NULL COMMENT 'Author full name',
    bio         TEXT         NULL COMMENT 'Author biography and literary career',
    nationality VARCHAR(50)  NULL COMMENT 'Author nationality',
    birth_date  DATE         NULL COMMENT 'Date of birth',
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT 'Record creation timestamp'
) ENGINE=InnoDB COMMENT='Authors biographical details';

-- =====================================================================
-- 3. TABLE: categories
-- Stores book genres and categories with hierarchical parent-child support
-- =====================================================================
CREATE TABLE categories (
    id          INT AUTO_INCREMENT PRIMARY KEY COMMENT 'Category ID (PK)',
    name        VARCHAR(100) NOT NULL UNIQUE COMMENT 'Category name (Unique)',
    description TEXT         NULL COMMENT 'Category description',
    parent_id   INT          NULL COMMENT 'Parent category ID (Self-referencing FK, NULL for top-level)',
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT 'Record creation timestamp',
    
    CONSTRAINT fk_categories_parent
        FOREIGN KEY (parent_id) REFERENCES categories(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Book categories supporting hierarchical sub-genres';

-- =====================================================================
-- 4. TABLE: books
-- Core catalog representing all published books
-- 1:N relationship with publishers
-- =====================================================================
CREATE TABLE books (
    id               INT AUTO_INCREMENT PRIMARY KEY COMMENT 'Book ID (PK)',
    title            VARCHAR(255)   NOT NULL COMMENT 'Book Title',
    isbn             VARCHAR(20)    NOT NULL UNIQUE COMMENT 'International Standard Book Number (ISBN, Unique)',
    price            DECIMAL(10, 2) NOT NULL COMMENT 'Catalog list price (> 0)',
    stock_quantity   INT            NOT NULL DEFAULT 0 COMMENT 'Warehouse inventory stock (>= 0)',
    publication_date DATE           NULL COMMENT 'Date of publication',
    pages            INT            NULL COMMENT 'Total page count (> 0)',
    language         VARCHAR(50)    DEFAULT 'Tiếng Việt' COMMENT 'Language edition',
    description      TEXT           NULL COMMENT 'Synopsis and book summary',
    publisher_id     INT            NOT NULL COMMENT 'Publisher Reference (FK)',
    created_at       DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT 'Record creation timestamp',
    updated_at       DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Last update timestamp',
    
    -- Domain Check Constraints
    CONSTRAINT chk_books_price CHECK (price > 0),
    CONSTRAINT chk_books_stock CHECK (stock_quantity >= 0),
    CONSTRAINT chk_books_pages CHECK (pages IS NULL OR pages > 0),
    
    -- Referential Integrity Constraint
    CONSTRAINT fk_books_publisher
        FOREIGN KEY (publisher_id) REFERENCES publishers(id)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Book product catalog';

-- =====================================================================
-- 5. TABLE: book_authors
-- Junction table resolving Many-to-Many (M:N) relationship between books & authors
-- =====================================================================
CREATE TABLE book_authors (
    book_id    INT NOT NULL COMMENT 'Book reference (FK)',
    author_id  INT NOT NULL COMMENT 'Author reference (FK)',
    role       VARCHAR(50) DEFAULT 'Tác giả chính' COMMENT 'Author role (e.g. Lead Author, Co-Author, Translator)',
    PRIMARY KEY (book_id, author_id),
    CONSTRAINT fk_ba_book
        FOREIGN KEY (book_id) REFERENCES books(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_ba_author
        FOREIGN KEY (author_id) REFERENCES authors(id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Junction table for Books and Authors (M:N)';

-- =====================================================================
-- 6. TABLE: book_categories
-- Junction table resolving Many-to-Many (M:N) relationship between books & categories
-- =====================================================================
CREATE TABLE book_categories (
    book_id     INT NOT NULL COMMENT 'Book reference (FK)',
    category_id INT NOT NULL COMMENT 'Category reference (FK)',
    PRIMARY KEY (book_id, category_id),
    CONSTRAINT fk_bc_book
        FOREIGN KEY (book_id) REFERENCES books(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_bc_category
        FOREIGN KEY (category_id) REFERENCES categories(id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Junction table for Books and Categories (M:N)';

-- =====================================================================
-- 7. TABLE: customers
-- Customer user accounts and delivery profiles
-- =====================================================================
CREATE TABLE customers (
    id            INT AUTO_INCREMENT PRIMARY KEY COMMENT 'Customer ID (PK)',
    full_name     VARCHAR(100) NOT NULL COMMENT 'Customer full name',
    email         VARCHAR(100) NOT NULL UNIQUE COMMENT 'Unique login email',
    password_hash VARCHAR(255) NOT NULL COMMENT 'Salted password hash',
    phone         VARCHAR(20)  NULL COMMENT 'Contact telephone number',
    address       VARCHAR(255) NOT NULL COMMENT 'Default shipping and billing address',
    created_at    DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT 'Registration timestamp'
) ENGINE=InnoDB COMMENT='Customer profile accounts';

-- =====================================================================
-- 8. TABLE: orders
-- Order headers capturing transaction status, totals, and destinations
-- 1:N relationship with customers
-- =====================================================================
CREATE TABLE orders (
    id               INT AUTO_INCREMENT PRIMARY KEY COMMENT 'Order ID (PK)',
    customer_id      INT            NOT NULL COMMENT 'Customer reference (FK)',
    order_date       DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Order placement timestamp',
    status           ENUM('Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled') 
                     NOT NULL DEFAULT 'Pending' COMMENT 'Order workflow status',
    total_amount     DECIMAL(12, 2) NOT NULL DEFAULT 0.00 COMMENT 'Order grand total (>= 0)',
    shipping_address VARCHAR(255)   NOT NULL COMMENT 'Specific delivery destination for this order',
    payment_method   ENUM('COD', 'Credit Card', 'Bank Transfer', 'E-Wallet') 
                     NOT NULL DEFAULT 'COD' COMMENT 'Payment gateway/method',
    created_at       DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT 'Record creation timestamp',
    
    CONSTRAINT chk_orders_total CHECK (total_amount >= 0),
    CONSTRAINT fk_orders_customer
        FOREIGN KEY (customer_id) REFERENCES customers(id)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Customer order headers';

-- =====================================================================
-- 9. TABLE: order_items
-- Order line items resolving Many-to-Many (M:N) relationship between orders & books
-- =====================================================================
CREATE TABLE order_items (
    id          INT AUTO_INCREMENT PRIMARY KEY COMMENT 'Line item ID (PK)',
    order_id    INT            NOT NULL COMMENT 'Order reference (FK)',
    book_id     INT            NOT NULL COMMENT 'Book reference (FK)',
    quantity    INT            NOT NULL COMMENT 'Purchased quantity (> 0)',
    unit_price  DECIMAL(10, 2) NOT NULL COMMENT 'Point-in-time unit price at checkout (> 0)',
    subtotal    DECIMAL(12, 2) NOT NULL COMMENT 'Subtotal = quantity * unit_price (>= 0)',
    
    -- Prevent duplicate book lines within the same order
    CONSTRAINT uq_order_book UNIQUE (order_id, book_id),
    
    -- Domain Check Constraints
    CONSTRAINT chk_items_quantity   CHECK (quantity > 0),
    CONSTRAINT chk_items_unit_price CHECK (unit_price > 0),
    CONSTRAINT chk_items_subtotal   CHECK (subtotal >= 0),
    
    -- Foreign Key Actions
    CONSTRAINT fk_items_order
        FOREIGN KEY (order_id) REFERENCES orders(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_items_book
        FOREIGN KEY (book_id) REFERENCES books(id)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Line items per order (M:N between Orders and Books)';

-- =====================================================================
-- 10. TABLE: reviews
-- Customer book ratings and textual feedback
-- 1:N from customers, 1:N from books
-- =====================================================================
CREATE TABLE reviews (
    id          INT AUTO_INCREMENT PRIMARY KEY COMMENT 'Review ID (PK)',
    book_id     INT      NOT NULL COMMENT 'Book reference (FK)',
    customer_id INT      NOT NULL COMMENT 'Customer reviewer reference (FK)',
    rating      TINYINT  NOT NULL COMMENT 'Rating score (1 to 5 stars)',
    comment     TEXT     NULL COMMENT 'Review text commentary',
    review_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Review submission timestamp',
    
    -- Enforce single review per customer per book
    CONSTRAINT uq_customer_book_review UNIQUE (customer_id, book_id),
    
    -- Domain Check Constraint
    CONSTRAINT chk_reviews_rating CHECK (rating >= 1 AND rating <= 5),
    
    -- Foreign Key Actions
    CONSTRAINT fk_reviews_book
        FOREIGN KEY (book_id) REFERENCES books(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_reviews_customer
        FOREIGN KEY (customer_id) REFERENCES customers(id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Customer ratings and reviews';


-- =====================================================================
-- REALISTIC SAMPLE DATA INSERTION
-- Requirements Checklist:
--   - 5 Publishers (>= 4 required)
--   - 8 Authors (>= 6 required)
--   - 7 Categories with hierarchy (>= 5 required)
--   - 10 Books (>= 8 required)
--   - 6 Customers (>= 5 required)
--   - 6 Orders (>= 6 required) with 15 Order Items (> 12 required)
--   - 12 Reviews (>= 10 required)
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. Insert into publishers (5 records)
-- ---------------------------------------------------------------------
INSERT INTO publishers (id, name, address, phone, email, website) VALUES
(1, 'Nhà xuất bản Trẻ', '161B Lý Chính Thắng, Phường Võ Thị Sáu, Quận 3, TP. Hồ Chí Minh', '02839316289', 'hopthu@nxbtre.com.vn', 'https://www.nxbtre.com.vn'),
(2, 'Nhà xuất bản Kim Đồng', '55 Quang Trung, Phường Nguyễn Du, Quận Hai Bà Trưng, Hà Nội', '02439434730', 'cskh@nxbkimdong.com.vn', 'https://www.nxbkimdong.com.vn'),
(3, 'Nhà xuất bản Nhã Nam', '59 Đỗ Quang, Phường Trung Hòa, Quận Cầu Giấy, Hà Nội', '02435146875', 'contact@nhanam.vn', 'https://www.nhanam.vn'),
(4, 'Nhà xuất bản Tổng Hợp TP.HCM', '62 Nguyễn Thị Minh Khai, Phường Đa Kao, Quận 1, TP. Hồ Chí Minh', '02838225340', 'tonghop@nxbhcm.com.vn', 'https://nxbhcm.com.vn'),
(5, 'Nhà xuất bản Thông Tin và Truyền Thông', '115 Trần Duy Hưng, Cầu Giấy, Hà Nội', '02435772139', 'nxb.tttt@mic.gov.vn', 'https://nxbtttt.vn');

-- ---------------------------------------------------------------------
-- 2. Insert into authors (8 records)
-- ---------------------------------------------------------------------
INSERT INTO authors (id, name, bio, nationality, birth_date) VALUES
(1, 'Nguyễn Nhật Ánh', 'Nhà văn hàng đầu Việt Nam dành cho thiếu nhi và tuổi trẻ, tác giả nhiều truyện dài đoạt giải thưởng.', 'Việt Nam', '1955-05-07'),
(2, 'Nam Cao', 'Cây bút hiện thực xuất sắc của văn học Việt Nam hiện đại giai đoạn 1930 - 1945.', 'Việt Nam', '1915-10-29'),
(3, 'Haruki Murakami', 'Tiểu thuyết gia đương đại nổi tiếng của Nhật Bản, phong cách hiện thực huyền ảo đặc trưng.', 'Nhật Bản', '1949-01-12'),
(4, 'J.K. Rowling', 'Nữ nhà văn tài năng người Anh, tác giả của bộ tiểu thuyết giả tưởng kinh điển Harry Potter.', 'Vương quốc Anh', '1965-07-31'),
(5, 'Dale Carnegie', 'Tác giả và diễn giả nổi tiếng người Mỹ về nghệ thuật ứng xử và phát triển cá nhân.', 'Hoa Kỳ', '1888-11-24'),
(6, 'Nguyễn Du', 'Đại thi hào dân tộc Việt Nam, Danh nhân văn hóa thế giới với kiệt tác Đoạn Trường Tân Thanh.', 'Việt Nam', '1765-01-03'),
(7, 'Robert C. Martin', 'Kỹ sư phần mềm huyền thoại (Uncle Bob), đồng sáng lập Tuyên ngôn Agile và tác giả Clean Code.', 'Hoa Kỳ', '1952-12-05'),
(8, 'Yuval Noah Harari', 'Nhà sử học, triết gia người Israel, tác giả các cuốn sách nghiên cứu lịch sử vĩ mô.', 'Israel', '1976-02-24');

-- ---------------------------------------------------------------------
-- 3. Insert into categories (7 records, with parent-child hierarchy)
-- ---------------------------------------------------------------------
-- Top-level categories (parent_id IS NULL)
INSERT INTO categories (id, name, description, parent_id) VALUES
(1, 'Văn học', 'Các tác phẩm văn học nghệ thuật, hư cấu, tiểu thuyết, truyện ngắn, thơ ca', NULL),
(4, 'Khoa học - Công nghệ', 'Sách công nghệ thông tin, lập trình phần mềm, khoa học kỹ thuật hiện đại', NULL),
(6, 'Kỹ năng sống', 'Sách rèn luyện tư duy, kỹ năng mềm, giao tiếp và quản trị cuộc sống', NULL),
(7, 'Lịch sử - Xã hội', 'Sách nghiên cứu tiến trình lịch sử nhân loại, triết học và xã hội học', NULL);

-- Sub-categories (with parent_id)
INSERT INTO categories (id, name, description, parent_id) VALUES
(2, 'Tiểu thuyết', 'Các tác phẩm tiểu thuyết trường thiên trong nước và dịch phẩm quốc tế', 1),
(3, 'Truyện ngắn - Tản văn', 'Tuyển tập truyện ngắn đặc sắc, tản văn trữ tình và phóng sự', 1),
(5, 'Lập trình & Kỹ thuật phần mềm', 'Tài liệu kiến trúc phần mềm, thuật toán, cơ sở dữ liệu và clean code', 4);

-- ---------------------------------------------------------------------
-- 4. Insert into books (10 records)
-- ---------------------------------------------------------------------
INSERT INTO books (id, title, isbn, price, stock_quantity, publication_date, pages, language, description, publisher_id) VALUES
(1, 'Mắt Biếc', '978-604-1-18234-5', 110000.00, 45, '2019-09-15', 300, 'Tiếng Việt', 'Câu chuyện tình đơn phương đầy trăn trở giữa Ngạn và Hà Lan nơi làng Đo Đo.', 1),
(2, 'Cho Tôi Xin Một Vé Đi Tuổi Thơ', '978-604-1-17520-0', 95000.00, 60, '2020-03-10', 216, 'Tiếng Việt', 'Chuyến tàu quay về miền ký ức tuổi thơ trong sáng, hồn nhiên và đầy ắp tiếng cười.', 1),
(3, 'Chí Phèo - Tuyển Tập Nam Cao', '978-604-2-08912-3', 85000.00, 30, '2018-05-20', 280, 'Tiếng Việt', 'Tuyển tập những tác phẩm hiện thực phê phán đỉnh cao về bi kịch tha hóa của người nông dân.', 2),
(4, 'Rừng Na Uy', '978-604-56-4581-9', 140000.00, 25, '2021-01-15', 550, 'Tiếng Việt', 'Tác phẩm đưa tên tuổi Murakami ra toàn cầu với chủ đề nỗi cô đơn và sự mất mát tuổi trẻ.', 3),
(5, 'Harry Potter và Hòn Đá Phù Thủy', '978-604-1-09823-1', 175000.00, 50, '2017-08-10', 368, 'Tiếng Việt', 'Tập mở đầu của thế giới phù thủy Hogwarts đầy kỳ diệu và cuộc phiêu lưu của Harry Potter.', 1),
(6, 'Đắc Nhân Tâm', '978-604-58-7212-3', 98000.00, 100, '2021-06-01', 320, 'Tiếng Việt', 'Cuốn sách nghệ thuật thu phục lòng người bán chạy nhất mọi thời đại.', 4),
(7, 'Truyện Kiều', '978-604-2-12345-6', 125000.00, 35, '2019-11-20', 412, 'Tiếng Việt', 'Kiệt tác thơ lục bát bất hủ phản ánh số phận người phụ nữ tài sắc trong xã hội phong kiến.', 2),
(8, 'Clean Code: A Handbook of Agile Software Craftsmanship', '978-013-2-35088-4', 350000.00, 20, '2016-04-12', 464, 'Tiếng Anh', 'Hướng dẫn toàn diện về tư duy viết mã nguồn sạch, dễ đọc, dễ bảo trì cho lập trình viên.', 5),
(9, 'Sapiens: Lược Sử Loài Người', '978-604-56-5544-3', 210000.00, 40, '2020-10-05', 560, 'Tiếng Việt', 'Hành trình tiến hóa ngoạn mục của loài người từ sinh vật tầm thường đến bá chủ Trái Đất.', 3),
(10, 'Clean Architecture: A Craftsman Guide to Software Structure', '978-013-4-49416-6', 380000.00, 15, '2018-09-17', 432, 'Tiếng Anh', 'Cẩm nang thiết kế kiến trúc hệ thống phần mềm mở rộng, độc lập và chuẩn mực.', 5);

-- ---------------------------------------------------------------------
-- 5. Insert into book_authors (M:N Books <-> Authors)
-- ---------------------------------------------------------------------
INSERT INTO book_authors (book_id, author_id, role) VALUES
(1, 1, 'Tác giả chính'),  -- Mắt Biếc - Nguyễn Nhật Ánh
(2, 1, 'Tác giả chính'),  -- Cho Tôi Xin Một Vé Đi Tuổi Thơ - Nguyễn Nhật Ánh
(3, 2, 'Tác giả chính'),  -- Chí Phèo - Nam Cao
(4, 3, 'Tác giả chính'),  -- Rừng Na Uy - Haruki Murakami
(5, 4, 'Tác giả chính'),  -- Harry Potter - J.K. Rowling
(6, 5, 'Tác giả chính'),  -- Đắc Nhân Tâm - Dale Carnegie
(7, 6, 'Tác giả chính'),  -- Truyện Kiều - Nguyễn Du
(8, 7, 'Tác giả chính'),  -- Clean Code - Robert C. Martin
(9, 8, 'Tác giả chính'),  -- Sapiens - Yuval Noah Harari
(10, 7, 'Tác giả chính'); -- Clean Architecture - Robert C. Martin

-- ---------------------------------------------------------------------
-- 6. Insert into book_categories (M:N Books <-> Categories)
-- ---------------------------------------------------------------------
INSERT INTO book_categories (book_id, category_id) VALUES
(1, 1), -- Mắt Biếc: Văn học
(1, 2), -- Mắt Biếc: Tiểu thuyết
(2, 1), -- Cho Tôi Xin Một Vé: Văn học
(2, 3), -- Cho Tôi Xin Một Vé: Truyện ngắn - Tản văn
(3, 1), -- Chí Phèo: Văn học
(3, 3), -- Chí Phèo: Truyện ngắn - Tản văn
(4, 1), -- Rừng Na Uy: Văn học
(4, 2), -- Rừng Na Uy: Tiểu thuyết
(5, 1), -- Harry Potter: Văn học
(5, 2), -- Harry Potter: Tiểu thuyết
(6, 6), -- Đắc Nhân Tâm: Kỹ năng sống
(7, 1), -- Truyện Kiều: Văn học
(8, 4), -- Clean Code: Khoa học - Công nghệ
(8, 5), -- Clean Code: Lập trình & Kỹ thuật phần mềm
(9, 7), -- Sapiens: Lịch sử - Xã hội
(10, 4), -- Clean Architecture: Khoa học - Công nghệ
(10, 5); -- Clean Architecture: Lập trình & Kỹ thuật phần mềm

-- ---------------------------------------------------------------------
-- 7. Insert into customers (6 records)
-- ---------------------------------------------------------------------
INSERT INTO customers (id, full_name, email, password_hash, phone, address) VALUES
(1, 'Trần Văn An', 'an.tran@gmail.com', '$2y$10$abcdefghijklmnopqrstuv1234567890abcdefghijklmnopqrstuv', '0901234567', '123 Lê Lợi, Phường Bến Nghé, Quận 1, TP. Hồ Chí Minh'),
(2, 'Lê Thị Bích', 'bich.le@yahoo.com', '$2y$10$1234567890abcdefghijklmnopqrstuvwxyz1234567890abcdefg', '0912345678', '45 Hai Bà Trưng, Phường Tràng Tiền, Quận Hoàn Kiếm, Hà Nội'),
(3, 'Phạm Quốc Cường', 'cuong.pham@outlook.com', '$2y$10$7890abcdefghijklmnopqrstuvwxyz123456abcdefghijklmnopqr', '0987654321', '78 Bạch Đằng, Phường Thạch Thang, Quận Hải Châu, TP. Đà Nẵng'),
(4, 'Hoàng Thị Dung', 'dung.hoang@gmail.com', '$2y$10$abcdef1234567890ghijklmnopqrstuvwxyzabcdefghijklmnopqr', '0934567890', '12 Nguyễn Huệ, Phường Vĩnh Ninh, TP. Huế, Thừa Thiên Huế'),
(5, 'Vũ Minh Đức', 'duc.vu@gmail.com', '$2y$10$xyz1234567890abcdefghijklmnopqrstuvwxyzabcdefghijklmnop', '0945678901', '88 Trần Phú, Phường Lộc Thọ, TP. Nha Trang, Khánh Hòa'),
(6, 'Nguyễn Phương Thảo', 'thao.nguyen@gmail.com', '$2y$10$passhashsample1234567890abcdefghijklmnopqrstuvwxyzabcdef', '0978123456', '24 Đại Cồ Việt, Phường Lê Đại Hành, Quận Hai Bà Trưng, Hà Nội');

-- ---------------------------------------------------------------------
-- 8. Insert into orders (6 records)
-- ---------------------------------------------------------------------
INSERT INTO orders (id, customer_id, order_date, status, total_amount, shipping_address, payment_method) VALUES
(1, 1, '2026-09-01 09:30:00', 'Delivered', 413000.00, '123 Lê Lợi, Phường Bến Nghé, Quận 1, TP. Hồ Chí Minh', 'Credit Card'),
(2, 2, '2026-09-05 14:15:00', 'Delivered', 490000.00, '45 Hai Bà Trưng, Phường Tràng Tiền, Quận Hoàn Kiếm, Hà Nội', 'COD'),
(3, 3, '2026-09-12 11:00:00', 'Shipped',   940000.00, '78 Bạch Đằng, Phường Thạch Thang, Quận Hải Châu, TP. Đà Nẵng', 'Bank Transfer'),
(4, 4, '2026-09-18 16:45:00', 'Processing',295000.00, '12 Nguyễn Huệ, Phường Vĩnh Ninh, TP. Huế, Thừa Thiên Huế', 'E-Wallet'),
(5, 5, '2026-09-25 10:20:00', 'Pending',   446000.00, '88 Trần Phú, Phường Lộc Thọ, TP. Nha Trang, Khánh Hòa', 'COD'),
(6, 6, '2026-10-02 20:10:00', 'Delivered', 385000.00, '24 Đại Cồ Việt, Phường Lê Đại Hành, Quận Hai Bà Trưng, Hà Nội', 'Bank Transfer');

-- ---------------------------------------------------------------------
-- 9. Insert into order_items (15 records total across 6 orders)
-- Order 1: 220,000 + 95,000 + 98,000 = 413,000
-- Order 2: 140,000 + 350,000 = 490,000
-- Order 3: 350,000 + 380,000 + 210,000 = 940,000
-- Order 4: 170,000 + 125,000 = 295,000
-- Order 5: 110,000 + 140,000 + 196,000 = 446,000
-- Order 6: 175,000 + 210,000 = 385,000
-- ---------------------------------------------------------------------
-- Order 1 Items
INSERT INTO order_items (order_id, book_id, quantity, unit_price, subtotal) VALUES
(1, 1, 2, 110000.00, 220000.00),
(1, 2, 1,  95000.00,  95000.00),
(1, 6, 1,  98000.00,  98000.00);

-- Order 2 Items
INSERT INTO order_items (order_id, book_id, quantity, unit_price, subtotal) VALUES
(2, 4, 1, 140000.00, 140000.00),
(2, 5, 2, 175000.00, 350000.00);

-- Order 3 Items
INSERT INTO order_items (order_id, book_id, quantity, unit_price, subtotal) VALUES
(3, 8,  1, 350000.00, 350000.00),
(3, 10, 1, 380000.00, 380000.00),
(3, 9,  1, 210000.00, 210000.00);

-- Order 4 Items
INSERT INTO order_items (order_id, book_id, quantity, unit_price, subtotal) VALUES
(4, 3, 2,  85000.00, 170000.00),
(4, 7, 1, 125000.00, 125000.00);

-- Order 5 Items
INSERT INTO order_items (order_id, book_id, quantity, unit_price, subtotal) VALUES
(5, 1, 1, 110000.00, 110000.00),
(5, 4, 1, 140000.00, 140000.00),
(5, 6, 2,  98000.00, 196000.00);

-- Order 6 Items
INSERT INTO order_items (order_id, book_id, quantity, unit_price, subtotal) VALUES
(6, 5, 1, 175000.00, 175000.00),
(6, 9, 1, 210000.00, 210000.00);

-- ---------------------------------------------------------------------
-- 10. Insert into reviews (12 records)
-- ---------------------------------------------------------------------
INSERT INTO reviews (book_id, customer_id, rating, comment, review_date) VALUES
(1, 1, 5, 'Một tác phẩm tuyệt vời của nhà văn Nguyễn Nhật Ánh, câu chuyện tình thơ mộng nhưng đọng lại nỗi buồn khôn nguôi.', '2026-09-08 10:00:00'),
(2, 1, 5, 'Đọc cuốn này như được một lần nữa trở về với tuổi thơ tinh nghịch, câu từ mộc mạc và dí dỏm sâu cay.', '2026-09-09 15:30:00'),
(4, 2, 4, 'Nỗi buồn mênh mang, giai điệu cô đơn bao trùm cuốn sách, phong cách Murakami không lẫn vào đâu được.', '2026-09-10 11:20:00'),
(5, 2, 5, 'Thế giới phù thủy mở ra vô cùng lôi cuốn, dịch giả chuyển ngữ tiếng Việt cực kỳ sinh động và hấp dẫn.', '2026-09-11 20:45:00'),
(8, 3, 5, 'Cuốn sách gối đầu giường của mọi kỹ sư phần mềm chuyên nghiệp, các quy tắc đặt tên và refactor rất thực tế.', '2026-09-16 09:15:00'),
(10, 3, 5, 'Kiến trúc phần mềm chuẩn mực, giải thích sáng rõ về ranh giới hệ thống, nguyên lý SOLID và Dependency Inversion.', '2026-09-17 14:00:00'),
(9, 3, 5, 'Góc nhìn lịch sử đột phá và khai phóng tư duy, giải thích rõ cách loài người làm chủ chuỗi thức ăn toàn cầu.', '2026-09-18 08:30:00'),
(3, 4, 4, 'Giá trị hiện thực sâu sắc, phản ánh chân thực số phận bế tắc của người nông dân trước Cách mạng tháng Tám.', '2026-09-22 17:10:00'),
(7, 4, 5, 'Kiệt tác thi ca bất hủ của dân tộc, chất lượng in ấn trang nhã và phần khảo dị chú thích rất kỹ lưỡng.', '2026-09-23 19:25:00'),
(6, 5, 4, 'Nhiều bài học giao tiếp và thấu cảm sâu sắc, xứng đáng là cẩm nang ứng xử cho thế hệ trẻ.', '2026-09-28 12:40:00'),
(1, 5, 5, 'Sách đóng gói cẩn thận, giấy đẹp, đọc lại lần thứ hai vẫn thấy rưng rưng với cái kết ở ga tàu.', '2026-09-29 16:50:00'),
(9, 6, 5, 'Một cuốn sách tuyệt vời, khối lượng kiến thức khổng lồ nhưng văn phong dí dỏm lôi cuốn từ đầu đến cuối.', '2026-10-05 21:00:00');


-- =====================================================================
-- VERIFICATION QUERIES (INTEGRITY & RELATIONSHIP CHECKS)
-- Run these queries after importing to verify 100% compliance
-- =====================================================================

-- 1. Comprehensive Book Catalog Query (Validating M:N with Authors & Categories, and 1:N with Publishers)
SELECT 
    b.id AS book_id,
    b.title AS book_title,
    b.price,
    b.stock_quantity,
    p.name AS publisher_name,
    GROUP_CONCAT(DISTINCT a.name SEPARATOR ', ') AS authors,
    GROUP_CONCAT(DISTINCT c.name SEPARATOR ', ') AS categories
FROM books b
JOIN publishers p ON b.publisher_id = p.id
LEFT JOIN book_authors ba ON b.id = ba.book_id
LEFT JOIN authors a ON ba.author_id = a.id
LEFT JOIN book_categories bc ON b.id = bc.book_id
LEFT JOIN categories c ON bc.category_id = c.id
GROUP BY b.id, b.title, b.price, b.stock_quantity, p.name;

-- 2. Financial Integrity Check (Validating that recorded total_amount equals sum of line item subtotals)
SELECT 
    o.id AS order_id,
    c.full_name AS customer_name,
    o.order_date,
    o.status,
    o.total_amount AS recorded_total,
    SUM(oi.subtotal) AS calculated_total,
    COUNT(oi.id) AS total_items,
    CASE 
        WHEN o.total_amount = SUM(oi.subtotal) THEN 'KHỚP CHÍNH XÁC (MATCH)' 
        ELSE 'LỖI LỆCH TIỀN (MISMATCH)' 
    END AS integrity_check
FROM orders o
JOIN customers c ON o.customer_id = c.id
JOIN order_items oi ON o.id = oi.order_id
GROUP BY o.id, c.full_name, o.order_date, o.status, o.total_amount;

-- 3. Book Reviews & Ratings Summary (Validating 1:N from books & customers)
SELECT 
    b.title AS book_title,
    COUNT(r.id) AS total_reviews,
    ROUND(AVG(r.rating), 2) AS average_rating
FROM books b
LEFT JOIN reviews r ON b.id = r.book_id
GROUP BY b.id, b.title
HAVING total_reviews > 0
ORDER BY average_rating DESC;
