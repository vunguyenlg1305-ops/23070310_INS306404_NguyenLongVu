-- =====================================================================
-- Student Name : Nguyen Long Vu
-- Student ID   : [Mã số sinh viên của bạn]
-- Assignment   : INS3064 - Homework 4 (University Course Registration System)
-- Date         : 2026-10-12
-- Description  : Complete SQL script to create the university_db database,
--                all tables with proper constraints, and sample data.
-- =====================================================================

-- Đảm bảo tính lặp lại (Idempotency): Xóa database cũ nếu đã tồn tại và tạo mới
DROP DATABASE IF EXISTS university_db;
CREATE DATABASE university_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE university_db;

-- ---------------------------------------------------------------------
-- 1. Table: departments (Lưu trữ thông tin khoa)
-- Không có khóa ngoại phụ thuộc.
-- ---------------------------------------------------------------------
CREATE TABLE departments (
    id          INT AUTO_INCREMENT PRIMARY KEY COMMENT 'Mã khoa (Khóa chính)',
    name        VARCHAR(100) NOT NULL UNIQUE COMMENT 'Tên khoa (Duy nhất)',
    code        VARCHAR(10)  NOT NULL UNIQUE COMMENT 'Mã viết tắt của khoa (Duy nhất)',
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT 'Thời gian tạo bản ghi'
) ENGINE=InnoDB COMMENT='Bảng lưu thông tin các khoa học thuật';

-- ---------------------------------------------------------------------
-- 2. Table: semesters (Lưu trữ thông tin học kỳ)
-- Không có khóa ngoại phụ thuộc.
-- ---------------------------------------------------------------------
CREATE TABLE semesters (
    id          INT AUTO_INCREMENT PRIMARY KEY COMMENT 'Mã học kỳ (Khóa chính)',
    name        VARCHAR(50)  NOT NULL UNIQUE COMMENT 'Tên học kỳ (Ví dụ: Fall 2025, Spring 2026)',
    start_date  DATE         NOT NULL COMMENT 'Ngày bắt đầu học kỳ',
    end_date    DATE         NOT NULL COMMENT 'Ngày kết thúc học kỳ'
) ENGINE=InnoDB COMMENT='Bảng lưu thông tin các học kỳ';

-- ---------------------------------------------------------------------
-- 3. Table: instructors (Lưu trữ thông tin giảng viên)
-- Thuộc về một khoa cụ thể.
-- ---------------------------------------------------------------------
CREATE TABLE instructors (
    id              INT AUTO_INCREMENT PRIMARY KEY COMMENT 'Mã giảng viên (Khóa chính)',
    instructor_code VARCHAR(20)  NOT NULL UNIQUE COMMENT 'Mã số giảng viên',
    full_name       VARCHAR(100) NOT NULL COMMENT 'Họ và tên giảng viên',
    email           VARCHAR(100) NOT NULL UNIQUE COMMENT 'Email liên hệ',
    gender          ENUM('Nam', 'Nữ', 'Khác') NOT NULL DEFAULT 'Nam' COMMENT 'Giới tính',
    department_id   INT          NOT NULL COMMENT 'Mã khoa công tác (Khóa ngoại)',
    CONSTRAINT fk_instructor_department 
        FOREIGN KEY (department_id) REFERENCES departments(id) 
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Bảng lưu thông tin giảng viên';

-- ---------------------------------------------------------------------
-- 4. Table: students (Lưu trữ thông tin sinh viên)
-- Thuộc về một khoa (chuyên ngành).
-- ---------------------------------------------------------------------
CREATE TABLE students (
    id              INT AUTO_INCREMENT PRIMARY KEY COMMENT 'Mã sinh viên (Khóa chính)',
    student_code    VARCHAR(20)  NOT NULL UNIQUE COMMENT 'Mã số sinh viên (MSSV)',
    full_name       VARCHAR(100) NOT NULL COMMENT 'Họ và tên sinh viên',
    email           VARCHAR(100) NOT NULL UNIQUE COMMENT 'Email sinh viên',
    gender          ENUM('Nam', 'Nữ', 'Khác') NOT NULL DEFAULT 'Nam' COMMENT 'Giới tính',
    date_of_birth   DATE         NOT NULL COMMENT 'Ngày sinh',
    gpa             DECIMAL(3,2) DEFAULT 0.00 CHECK (gpa >= 0.00 AND gpa <= 4.00) COMMENT 'Điểm trung bình tích lũy (0.00 - 4.00)',
    department_id   INT          NOT NULL COMMENT 'Mã khoa/chuyên ngành (Khóa ngoại)',
    CONSTRAINT fk_student_department 
        FOREIGN KEY (department_id) REFERENCES departments(id) 
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Bảng lưu thông tin sinh viên';

-- ---------------------------------------------------------------------
-- 5. Table: courses (Lưu trữ thông tin học phần/môn học)
-- Thuộc về một khoa quản lý và do một giảng viên phụ trách chính.
-- ---------------------------------------------------------------------
CREATE TABLE courses (
    id            INT AUTO_INCREMENT PRIMARY KEY COMMENT 'Mã môn học (Khóa chính)',
    course_code   VARCHAR(20)  NOT NULL UNIQUE COMMENT 'Mã học phần',
    title         VARCHAR(150) NOT NULL COMMENT 'Tên môn học',
    credits       INT          NOT NULL CHECK (credits > 0) COMMENT 'Số tín chỉ',
    description   TEXT         COMMENT 'Mô tả chi tiết môn học',
    department_id INT          NOT NULL COMMENT 'Khoa quản lý môn học (Khóa ngoại)',
    instructor_id INT          NOT NULL COMMENT 'Giảng viên phụ trách (Khóa ngoại)',
    CONSTRAINT fk_course_department 
        FOREIGN KEY (department_id) REFERENCES departments(id) 
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_course_instructor 
        FOREIGN KEY (instructor_id) REFERENCES instructors(id) 
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Bảng lưu thông tin các môn học';

-- ---------------------------------------------------------------------
-- 6. Table: enrollments (Bảng trung gian liên kết Sinh viên - Môn học - Học kỳ)
-- ---------------------------------------------------------------------
CREATE TABLE enrollments (
    id          INT AUTO_INCREMENT PRIMARY KEY COMMENT 'Mã đăng ký (Khóa chính)',
    student_id  INT          NOT NULL COMMENT 'Mã sinh viên (Khóa ngoại)',
    course_id   INT          NOT NULL COMMENT 'Mã môn học (Khóa ngoại)',
    semester_id INT          NOT NULL COMMENT 'Mã học kỳ (Khóa ngoại)',
    grade       DECIMAL(3,2) DEFAULT NULL CHECK (grade IS NULL OR (grade >= 0.00 AND grade <= 4.00)) COMMENT 'Điểm số môn học (0.00 - 4.00)',
    enrolled_at DATETIME     DEFAULT CURRENT_TIMESTAMP COMMENT 'Thời gian đăng ký',
    
    -- Khóa ngoại liên kết
    CONSTRAINT fk_enrollment_student 
        FOREIGN KEY (student_id) REFERENCES students(id) 
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_enrollment_course 
        FOREIGN KEY (course_id) REFERENCES courses(id) 
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_enrollment_semester 
        FOREIGN KEY (semester_id) REFERENCES semesters(id) 
        ON DELETE CASCADE ON UPDATE CASCADE,
        
    -- Đảm bảo sinh viên không đăng ký trùng một môn trong cùng một học kỳ
    CONSTRAINT unique_enrollment UNIQUE (student_id, course_id, semester_id)
) ENGINE=InnoDB COMMENT='Bảng ghi nhận kết quả đăng ký học phần của sinh viên';


-- =====================================================================
-- INSERT SAMPLE DATA (Dữ liệu mẫu tiếng Việt)
-- =====================================================================

-- 1. Departments (5 bản ghi)
INSERT INTO departments (name, code) VALUES
('Công nghệ Thông tin', 'IT'),
('Quản trị Kinh doanh', 'BA'),
('Kỹ thuật Điện - Điện tử', 'EE'),
('Ngôn ngữ Anh', 'ENG'),
('Kế toán - Kiểm toán', 'ACC');

-- 2. Semesters (5 bản ghi)
INSERT INTO semesters (name, start_date, end_date) VALUES
('Fall 2024', '2024-09-05', '2025-01-15'),
('Spring 2025', '2025-02-10', '2025-06-30'),
('Fall 2025', '2025-09-05', '2026-01-15'),
('Spring 2026', '2026-02-10', '2026-06-30'),
('Fall 2026', '2026-09-05', '2027-01-15');

-- 3. Instructors (5 bản ghi)
INSERT INTO instructors (instructor_code, full_name, email, gender, department_id) VALUES
('INS101', 'Nguyễn Văn Minh', 'minh.nv@university.edu.vn', 'Nam', 1),
('INS102', 'Trần Thị Mai', 'mai.tt@university.edu.vn', 'Nữ', 1),
('INS201', 'Lê Hoàng Long', 'long.lh@university.edu.vn', 'Nam', 2),
('INS301', 'Phạm Thị Lan', 'lan.pt@university.edu.vn', 'Nữ', 3),
('INS401', 'Hoàng Văn Hùng', 'hung.hv@university.edu.vn', 'Nam', 4);

-- 4. Students (5 bản ghi)
INSERT INTO students (student_code, full_name, email, gender, date_of_birth, gpa, department_id) VALUES
('SV2026001', 'Nguyễn Long Vũ', 'vu.nl@student.edu.vn', 'Nam', '2005-03-15', 3.65, 1),
('SV2026002', 'Trần Bảo Ngọc', 'ngoc.tb@student.edu.vn', 'Nữ', '2005-07-22', 3.80, 1),
('SV2026003', 'Lê Minh Tuấn', 'tuan.lm@student.edu.vn', 'Nam', '2005-11-04', 3.20, 2),
('SV2026004', 'Phạm Thu Hằng', 'hang.pt@student.edu.vn', 'Nữ', '2005-01-19', 3.50, 3),
('SV2026005', 'Võ Hoàng Gia Huy', 'huy.vhg@student.edu.vn', 'Nam', '2005-09-30', 3.10, 4);

-- 5. Courses (5 bản ghi)
INSERT INTO courses (course_code, title, credits, description, department_id, instructor_id) VALUES
('INS3064', 'Cơ sở dữ liệu quan hệ và MySQL', 3, 'Học phần về thiết kế CSDL quan hệ, cú pháp SQL nâng cao và quản trị MySQL.', 1, 1),
('IT1010', 'Nhập môn Lập trình C', 3, 'Khái niệm cơ bản về lập trình cấu trúc, biến, mảng và con trỏ.', 1, 2),
('BA1001', 'Quản trị học đại cương', 3, 'Các nguyên lý cơ bản về quản trị doanh nghiệp và tổ chức.', 2, 3),
('EE2001', 'Mạch điện tử cơ bản', 4, 'Phân tích các linh kiện điện tử, bán dẫn và mạch khuếch đại.', 3, 4),
('ENG101', 'Tiếng Anh chuyên ngành kỹ thuật', 2, 'Rèn luyện kỹ năng đọc hiểu tài liệu kỹ thuật bằng tiếng Anh.', 4, 5);

-- 6. Enrollments (10 bản ghi liên kết sinh viên - môn học - học kỳ)
INSERT INTO enrollments (student_id, course_id, semester_id, grade) VALUES
(1, 1, 4, 3.80), -- Nguyễn Long Vũ học INS3064 (Spring 2026)
(1, 2, 3, 3.50), -- Nguyễn Long Vũ học IT1010 (Fall 2025)
(2, 1, 4, 4.00), -- Trần Bảo Ngọc học INS3064 (Spring 2026)
(2, 2, 3, 3.70), -- Trần Bảo Ngọc học IT1010 (Fall 2025)
(3, 3, 3, 3.20), -- Lê Minh Tuấn học BA1001 (Fall 2025)
(3, 1, 4, 3.00), -- Lê Minh Tuấn học INS3064 (Spring 2026)
(4, 4, 3, 3.40), -- Phạm Thu Hằng học EE2001 (Fall 2025)
(4, 1, 4, 3.60), -- Phạm Thu Hằng học INS3064 (Spring 2026)
(5, 5, 3, 3.10), -- Võ Hoàng Gia Huy học ENG101 (Fall 2025)
(5, 1, 4, 3.30); -- Võ Hoàng Gia Huy học INS3064 (Spring 2026)